#include <t2fs.h>
#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[])
{
    format2(10);
}



